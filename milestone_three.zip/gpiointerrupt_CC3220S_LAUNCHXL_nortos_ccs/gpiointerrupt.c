/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"



enum SOS_States {SOS_INIT, SOS_START, SOS_FINISH, OK_START} SOS_State;

int i = 0;

volatile unsigned char timerFlag = 0;

void timerFlagISR(){
    timerFlag = 1;
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle an LED */
    timerFlagISR();
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Raise the timer flag */
    timerFlagISR();
}

//dot: red on for 500 ms
//dash: green on for 1500 ms
void SOS(){
    while(i < 42){
        if(i < 6){
            GPIO_toggle(CONFIG_GPIO_LED_0);
            i++;
    }
        else{
            if(i < 36){
                if(i % 3 == 0){
                    GPIO_toggle(CONFIG_GPIO_LED_1);
                    i++;
                }
                else{
                    i++;
            }
            }
            else{
                if(i < 42){
                GPIO_toggle(CONFIG_GPIO_LED_0);
                i++;
            }
                else{
                    i++;
                }
            }
            }
        }
}


void OK(){
    while(i < 32){
        if(i % 3  == 0 && i < 18){
            GPIO_toggle(CONFIG_GPIO_LED_1);
            i++;
        }
        else{
            if(i < 24 && (i % 3) == 0){
                GPIO_toggle(CONFIG_GPIO_LED_1);
                i++;
            }
            else{
                if(i < 26){
                GPIO_toggle(CONFIG_GPIO_LED_0);
                i++;
            }
                else{
                    if(i % 3 == 0 ){
                        GPIO_toggle(CONFIG_GPIO_LED_1);
                        i++;
                    }
                    else{
                        i++;
                    }
                }
            }
        }
    }
}

void TickFctSOS(){
    switch(SOS_State){
        case SOS_INIT:
            if(1){
                i = 0;
                SOS_State = SOS_START;
            }
            break;
        case SOS_START:
            if(i < 42){
                SOS_State = SOS_START;
            }
            else if(timerFlag == 1) {
                //check if button push, set state to SOS_Finish, reset i = 0
                i = 0;
                SOS_State = OK_START;
            }
            else{
                SOS_State = SOS_FINISH;
            }
            break;
        case SOS_FINISH:
            //check for button push, set state to OK_Start if so, else to SOS_Start
            i = 0;
            //wait period
            while(i < 15){
                i++;
            }
            i = 0;
            timerFlag = 0;
            SOS_State = SOS_START;
            break;
        case OK_START:
            //blink OK, use i to increment through, set state to SOS_start and reset i
            // O: - - - K: - . -
            if(i < 32){
                SOS_State = OK_START;
            }
            else{
                SOS_State = SOS_FINISH;
            }
            break;
        default:
            SOS_State = SOS_FINISH;
            }// Transitions

    switch(SOS_State){ //actions
    case SOS_START:
        //{red on for 500, off for 500} x3, {green on for 1500, off for 1500} x3, {red on for 500, off for 500} x3
        SOS();
    case OK_START:
        OK();
    }

    }
/*
 * ======== Inserted code ===========
 */
#include <ti/drivers/Timer.h>
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TickFctSOS();
}
void initTimer(void)
{
 Timer_Handle timer0;
 Timer_Params params;
 Timer_init();
Timer_Params_init(&params);
params.period = 500000;
params.periodUnits = Timer_PERIOD_US;
params.timerMode = Timer_CONTINUOUS_CALLBACK;
params.timerCallback = timerCallback;





 timer0 = Timer_open(CONFIG_TIMER_0, &params);
 if (timer0 == NULL) {
 /* Failed to initialized timer */
 while (1) {}
 }
 if (Timer_start(timer0) == Timer_STATUS_ERROR) {
 /* Failed to start timer */
 while (1) {}
 }
}









/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    SOS_State = SOS_INIT;
    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    initTimer();
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }
    while(1){
        TickFctSOS();
    }

}
